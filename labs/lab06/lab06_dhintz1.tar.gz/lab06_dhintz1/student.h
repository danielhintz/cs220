#include "player_dhintz1.c" 
