#define NUMSLOTS 4

void initSlots();
void getBin(int bin, int slot);
int findSlot(int bin);
void getWidget(int bin);
void printEarnings();